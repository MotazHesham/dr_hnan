@extends('layouts.consultant')
@section('content')
    @include('partials.show_request_service',['user_type' => 'consultant'])
@endsection 
