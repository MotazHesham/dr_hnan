@extends('layouts.consultant')

@section('content')
    This is consultant Home .... 
    Statistics Comming Soon
@endsection