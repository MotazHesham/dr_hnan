@extends('layouts.admin')
@section('content')

    @include('partials.show_request_service',['user_type' => 'staff'])

@endsection