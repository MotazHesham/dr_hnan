@extends('layouts.client')

@section('content')
    This is Client Home...
    Statistics Comming Soon
@endsection