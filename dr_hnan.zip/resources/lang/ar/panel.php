<?php

return [
    'site_title' => 'HDAC',

];
