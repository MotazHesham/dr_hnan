<?php

return [
    'previous' => '«  السابق',
    'next'     => 'التالي »',

];
